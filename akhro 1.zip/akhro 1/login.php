<?php
// Start session to store login status
session_start();

// Check if form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Hardcoded credentials (you can replace this with database validation later)
    $username = "admin";
    $password = "12345";

    // Get form data
    $entered_username = $_POST['username'];
    $entered_password = $_POST['password'];

    // Check if entered credentials are correct
    if ($entered_username == $username && $entered_password == $password) {
        // Set session variable to indicate user is logged in
        $_SESSION['loggedin'] = true;

        // Redirect to the main page (main.php)
        header("Location: main.php");
        exit;
    } else {
        // If login fails, redirect back to login page with error
        header("Location: login.php?error=1");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="main.css">
</head>

<body>
    <!-- Top Left Logo -->
    <img src="images/left-logo.png" alt="Alpha Kappa Rho" class="top-left-logo">

    <div class="header-text">
        <h1 class="title">ALPHA KAPPA RHO</h1>
        <p class="subtitle">INTERNATIONAL HUMANITARIAN SERVICE FRATERNITY AND SORORITY</p>
        <p class="council">Zamboang City Council</p>
    </div>

    <!-- Login Form -->
    <div class="container">
        <div class="login-container">
            <img src="mainlogo/right.png" alt="AKRHO Logo" class="login-logo">
            <form method="POST" action="login.php">
                <input type="text" name="username" placeholder="Email" required class="username-input">
                <input type="password" name="password" placeholder="Password" required class="password-input">
                <button type="submit" class="sidebar-button">Login</button>
            </form>
            
            <!-- Error message for wrong credentials -->
            <?php if (isset($_GET['error'])): ?>
                <p style="color: red;">Invalid username or password!</p>
            <?php endif; ?>
        </div>
    </div>
</body>

</html>
